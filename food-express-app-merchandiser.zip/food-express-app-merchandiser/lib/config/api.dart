class FoodApi {
  static String rootUrl = 'http://demo.food-express.xyz';
  static String baseApi = rootUrl+'/api/v1';
}