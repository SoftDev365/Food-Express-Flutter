class User {
  final String email;
  final String name;
  final String token;
  final String phone;
  final String address;

  User({ this.email, this.name, this.phone,this.address,this.token });
}