<?php
/**
 * Created by PhpStorm.
 * User: dipok
 * Date: 24/4/20
 * Time: 8:59 PM
 */

return [

    'version' => 'MS41OmZvb2QtZXhwcmVzcw==',

    'project_name'  => 'food-express',

    'update_url'    => 'http://demo.inilabs.net/autoupdate/update/index',

    'file_url'      => 'http://demo.inilabs.net/autoupdate/updatefiles/food-express/',

    'file_extract_path' => storage_path('app/update/'),

    'root_path' => public_path(),
];
