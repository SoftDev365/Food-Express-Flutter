<?php

namespace App\Models;

class OrderProduct extends BaseModel
{
    //
}
