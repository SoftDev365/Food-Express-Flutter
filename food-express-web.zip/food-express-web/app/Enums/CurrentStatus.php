<?php
namespace App\Enums;

interface CurrentStatus
{
    const YES = 5;
    const NO  = 10;
}
