<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 2/16/20
 * Time: 5:21 PM
 */

namespace App\Enums;


interface LedgerType
{
    const DR = 1;
    const CR = 5;

}