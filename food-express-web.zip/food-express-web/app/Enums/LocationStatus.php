<?php
/**
 * Created by PhpStorm.
 * User: dipok
 * Date: 16/4/20
 * Time: 9:11 PM
 */

namespace App\Enums;


interface LocationStatus
{
    const ACTIVE   = 5;
    const INACTIVE = 10;
}