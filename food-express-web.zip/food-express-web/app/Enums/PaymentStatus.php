<?php
/**
 * Created by PhpStorm.
 * User: dipok
 * Date: 18/4/20
 * Time: 12:41 PM
 */

namespace App\Enums;


interface PaymentStatus
{
    const PAID   = 5;
    const UNPAID = 10;
}