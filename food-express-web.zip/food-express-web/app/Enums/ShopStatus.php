<?php
/**
 * Created by PhpStorm.
 * User: dipok
 * Date: 19/4/20
 * Time: 2:29 PM
 */

namespace App\Enums;


interface ShopStatus
{
    const ACTIVE   = 5;
    const INACTIVE = 10;
}