<?php
/**
 * Created by PhpStorm.
 * User: dipok
 * Date: 17/4/20
 * Time: 12:47 PM
 */

namespace App\Enums;

interface UserApplied
{
    const OWN   = 5;
    const ADMIN = 10;
}
