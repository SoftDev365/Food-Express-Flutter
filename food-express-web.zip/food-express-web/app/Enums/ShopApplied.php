<?php
/**
 * Created by PhpStorm.
 * User: dipok
 * Date: 17/4/20
 * Time: 12:47 PM
 */

namespace App\Enums;

interface ShopApplied
{
    const SHOPOWNER = 1;
    const ADMIN     = 0;
}
