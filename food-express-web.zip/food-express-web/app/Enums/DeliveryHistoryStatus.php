<?php


namespace App\Enums;



interface DeliveryHistoryStatus
{
    const ACCEPT = 5;
    const CANCEL = 10;
}
