<?php


namespace App\Enums;


interface ProductReceiveStatus
{
    const RECEIVE       = 5;
    const NOT_RECEIVE   = 10;
}
