<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 2/16/20
 * Time: 5:21 PM
 */

namespace App\Enums;

interface BalanceType
{
    const REGULAR = 1;
    const ADMIN   = 5;

}
