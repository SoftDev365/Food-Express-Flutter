<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 7/15/20
 * Time: 11:38 AM
 */

namespace App\Enums;


interface ProductRequested
{
    const NON_REQUESTED = 5;
    const REQUESTED     = 10;
}